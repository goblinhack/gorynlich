/* config.h.  Generated from config.h.in by configure.  */
/* config.h.in.  Generated from configure.in by autoheader.  */

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "apoorvupreti@gmail.com"

/* Define to the full name of this package. */
#define PACKAGE_NAME "sdlvisualtest"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "sdlvisualtest 0.01"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "sdlvisualtest"

/* Define to the home page for this package. */
#define PACKAGE_URL ""

/* Define to the version of this package. */
#define PACKAGE_VERSION "0.01"

/* Define to empty if `const' does not conform to ANSI C. */
/* #undef const */
