var searchData=
[
  ['variation',['variation',['../struct_s_d_l_visual_test___exhaustive_variator.html#a11c2995cf19b41c4a1b1f8d9b4081ff7',1,'SDLVisualTest_ExhaustiveVariator::variation()'],['../struct_s_d_l_visual_test___random_variator.html#a11c2995cf19b41c4a1b1f8d9b4081ff7',1,'SDLVisualTest_RandomVariator::variation()']]],
  ['variator_5ftype',['variator_type',['../struct_s_d_l_visual_test___harness_state.html#aaaa989ae89caee6d39c722cfe6907466',1,'SDLVisualTest_HarnessState']]],
  ['vars',['vars',['../struct_s_d_l_visual_test___variation.html#a1eab2e90f0195b4f4632eb19523aeadf',1,'SDLVisualTest_Variation']]],
  ['verify_5fdir',['verify_dir',['../struct_s_d_l_visual_test___harness_state.html#adc871112f24f61e2fff74a7a7fb9794f',1,'SDLVisualTest_HarnessState']]]
];
