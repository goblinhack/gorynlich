var searchData=
[
  ['categories',['categories',['../struct_s_d_l_visual_test___s_u_t_option.html#a6744d43d3ad17d06068dba9ee7b78c83',1,'SDLVisualTest_SUTOption']]],
  ['config',['config',['../struct_s_d_l_visual_test___exhaustive_variator.html#ab66b4220589b2e2b6e1fde7d6c20bd72',1,'SDLVisualTest_ExhaustiveVariator::config()'],['../struct_s_d_l_visual_test___random_variator.html#ab66b4220589b2e2b6e1fde7d6c20bd72',1,'SDLVisualTest_RandomVariator::config()']]]
];
