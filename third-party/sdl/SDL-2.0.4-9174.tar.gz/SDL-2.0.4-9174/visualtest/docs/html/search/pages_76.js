var searchData=
[
  ['visual_20and_20interactive_20test_20automation_20for_20sdl_202_2e0',['Visual and Interactive Test Automation for SDL 2.0',['../index.html',1,'']]]
];
